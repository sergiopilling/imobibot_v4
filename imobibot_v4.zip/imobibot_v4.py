#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
IMOBIBOT V3c — Execução Automática (Windows): PARTE 1 (gen) → PARTE 2 (serve)
----------------------------------------------------------------------------
Ao executar:  py imobibot_v3.py
1) Roda automaticamente a PARTE 1 (gera temp1_disponiveis.xlsx e temp2_perguntas.xlsx a partir de BD_catalogo.xlsx)
2) Em seguida inicia a PARTE 2 (servidor Flask que utiliza Ollama, mantendo o MESMO HTML original)

Subcomandos opcionais (se preferir explicitar):
  py imobibot_v3.py gen   --input BD_catalogo.xlsx --out-disp temp1_disponiveis.xlsx --out-qa temp2_perguntas.xlsx
  py imobibot_v3.py serve --host 0.0.0.0 --port 5000

Dependências (Windows):
  py -m pip install flask pandas numpy openpyxl
  # E Ollama instalado/rodando em outro terminal:
  #   ollama serve
  #   ollama pull llama3
  #   ollama pull nomic-embed-text
"""

from __future__ import annotations

import os
import re
import sys
import argparse
import unicodedata
from typing import List, Dict, Tuple, Optional, Any
from pathlib import Path

import numpy as np
import pandas as pd

# =============================================================================
# ==============================  PARTE 1 (gen)  ==============================
# =============================================================================

def _norm(s: str) -> str:
    if not isinstance(s, str):
        s = str(s)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", s.strip()).lower()


def _load_catalog(paths: List[str]) -> pd.DataFrame:
    """Tenta carregar a primeira planilha existente em `paths` (XLSX/CSV)."""
    last_err = None
    for p in paths:
        if not p:
            continue
        p = str(p)
        if os.path.exists(p):
            try:
                ext = Path(p).suffix.lower()
                if ext in {".xlsx", ".xlsm"}:
                    return pd.read_excel(p, engine="openpyxl")
                elif ext == ".csv":
                    return pd.read_csv(p, sep=",")
                else:
                    return pd.read_excel(p, engine="openpyxl")
            except Exception as e:
                last_err = e
    raise FileNotFoundError(f"Falha ao abrir catálogo em {paths}. Último erro: {last_err}")


def _build_column_map(df: pd.DataFrame) -> Dict[str, str]:
    cols_norm2orig = {_norm(c): c for c in df.columns}
    cand = {
        "codigo":       ["codigo","código","id","nome/codigo","cód","cod"],
        "disponivel":   ["disponivel (s/n)","disponível (s/n)","disponivel","disponibilidade","disponivel?","disponível?","disp"],
        "tipo":         ["tipo","tipo de imovel","categoria","categoria do imovel","tipo_imovel"],
        "negociacao":   ["negociacao","negociação","negociacao (venda, aluguel, ambos)","negócio","tipo_negocio","negociacao (venda, aluguel, ambos)"],
        "valor_venda":  ["valor de venda (r$)","valor de venda","preco de venda","preço de venda","venda","preco_venda"],
        "valor_aluguel":["valor de aluguel (r$)","valor de aluguel","aluguel","preco de aluguel","préço de aluguel","aluguel_r$","preco_aluguel","preço de aluguel"],
        "condominio":   ["valor do condominio","condominio","condomínio"],
        "iptu":         ["valor do iptu","iptu"],
        "quartos":      ["quant. dormitorios","quant. dormitórios","dormitorios","quartos","qtd_quartos","n_quartos"],
        "banheiros":    ["quant. banheiros","banheiros","qtd_banheiros","n_banheiros"],
        "vagas":        ["quant. vagas garagem","vagas","vagas garagem","qtd_vagas","n_vagas"],
        "mobiliado":    ["mobiliado","mobilhado"],
        "aceita_pet":   ["aceita pet","aceita pets","pet"],
        "endereco":     ["endereco","endereço","logradouro"],
        "bairro":       ["bairro"],
        "cidade":       ["cidade","municipio","município"],
        "estado":       ["estado (uf)","uf","estado"],
        "cep":          ["cep"],
        "area":         ["area total (m²)","área total (m²)","area total","área total","m2","m²","area_m2"],
        "andar":        ["andar","piso"],
        "elevador":     ["elevador (s/n)","elevador"],
        "sacada":       ["sacada / varanda (s/n)","sacada","varanda"],
        "servico":      ["area de servico (s/n)","área de serviço (s/n)","area de servico","área de serviço"],
        "churrasqueira":["churrasqueira / gourmet (s/n)","churrasqueira","gourmet"],
        "piscina":      ["piscina (s/n)","piscina"],
        "portaria":     ["portaria 24h (s/n)","portaria 24h","portaria"],
        "piso":         ["tipo de piso","piso","revestimento"],
        "financiamento":["aceita financiamento? (s/n)","aceita financiamento","financiamento"],
        "permuta":      ["aceita permuta? (s/n)","aceita permuta","permuta"],
        "fiador":       ["tipo de fiador","qual tipo do fiador?","fiador","fiador possivel","fiador possível","garantia fiador"],
    }
    out = {}
    for k, vs in cand.items():
        for v in vs:
            vnorm = _norm(v)
            if vnorm in cols_norm2orig:
                out[k] = cols_norm2orig[vnorm]
                break
    return out


def _yes(value) -> Optional[bool]:
    if isinstance(value, str):
        v = _norm(value)
        if v in {"s","sim","yes","y","true","verdadeiro"}: return True
        if v in {"n","nao","não","no","false","falso"}:    return False
        if v == "1": return True
    if isinstance(value, (int, float)): return bool(value)
    if isinstance(value, bool):         return value
    return None


def _currency(x) -> str:
    if pd.isna(x): return "não informado"
    try:
        return f"R$ {float(x):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return str(x)


def _canon_tipo(t: str) -> str:
    t = _norm(t)
    if t in {"apto","apartamento","apt","ap"}: return "apto"
    if t in {"loja","lojas"}:                  return "loja"
    if t in {"casa","casas"}:                  return "casa"
    if t in {"terreno","terrenos"}:            return "terreno"
    if t in {"imovel","imóvel","imoveis","imóveis"}: return "imovel"
    return t


def _gender(t: str) -> str:
    t = _canon_tipo(t);  return "f" if t in {"loja","casa"} else "m"


def _plural_noun(t: str) -> str:
    t = _canon_tipo(t)
    return {"loja":"lojas","casa":"casas","terreno":"terrenos","apto":"aptos","imovel":"imóveis"}.get(t, t+"s")


def _det_algum(t: str, plural: bool) -> str:
    return ("algumas" if plural else "alguma") if _gender(t)=="f" else ("alguns" if plural else "algum")


def _prep_de(t: str, plural: bool) -> str:
    return ("das" if plural else "da") if _gender(t)=="f" else ("dos" if plural else "do")


def _match_neg(neg_text: str, series: pd.Series) -> pd.Series:
    neg_text = _norm(neg_text);  s = series.astype(str).str.lower()
    has_v = "venda" in neg_text; has_a = ("alug" in neg_text) or ("alugar" in neg_text) or ("aluguel" in neg_text)
    if has_v and has_a: return s.str.contains("venda") | s.str.contains("alug") | s.str.contains("amb")
    if has_v:           return s.str.contains("venda") | s.str.contains("amb")
    if has_a:           return s.str.contains("alug") | s.str.contains("amb")
    return s.notna()


def _neg_category(text: str) -> str:
    t = _norm(str(text))
    has_v = "venda" in t; has_a = ("alug" in t) or ("alugar" in t) or ("aluguel" in t)
    if has_v and has_a: return "ambos"
    if has_v:           return "venda"
    if has_a:           return "alugar"
    return "indef"


def _filter(df: pd.DataFrame, colmap: Dict[str, str], tipo=None, negociacao=None, bairro=None, quartos=None):
    d = df
    if tipo and "tipo" in colmap:
        d = d[d[colmap["tipo"]].astype(str).str.lower() == str(tipo).lower()]
    if negociacao and "negociacao" in colmap:
        d = d[_match_neg(negociacao, d[colmap["negociacao"]])]
    if bairro and "bairro" in colmap:
        d = d[d[colmap["bairro"]].astype(str).str.lower() == str(bairro).lower()]
    if quartos is not None and "quartos" in colmap:
        d = d[pd.to_numeric(d[colmap["quartos"]], errors="coerce") >= float(quartos)]
    return d


def _codes_list(df: pd.DataFrame, colmap: Dict[str, str], limit=None) -> List[str]:
    if "codigo" in colmap:
        lst = df[colmap["codigo"]].astype(str).tolist()
        return lst[:limit] if limit else lst
    idx = df.index.astype(str).tolist()
    return idx[:limit] if limit else idx


def _brief_desc(r: pd.Series, colmap: Dict[str, str], negociacao: Optional[str] = None) -> str:
    cod = str(r.get(colmap.get("codigo", ""), "")) or "sem código"
    tipo = _canon_tipo(str(r.get(colmap.get("tipo", ""), "")).lower() or "imovel")
    qtxt = "dormitórios n/d"
    if "quartos" in colmap:
        q = pd.to_numeric(r[colmap["quartos"]], errors="coerce")
        if pd.notna(q): qtxt = f"{int(q)} dormitórios"
    price_col = None
    if negociacao:
        nrm = _norm(negociacao)
        if "alug" in nrm and "valor_aluguel" in colmap: price_col = colmap["valor_aluguel"]
        elif "venda" in nrm and "valor_venda" in colmap: price_col = colmap["valor_venda"]
    if price_col is None:
        price_col = colmap.get("valor_aluguel") or colmap.get("valor_venda")
    price = _currency(r[price_col]) if price_col and price_col in r.index else "não informado"
    extras = []
    if "condominio" in colmap and pd.notna(r.get(colmap["condominio"], np.nan)):
        extras.append(f"condomínio {_currency(r[colmap['condominio']])}")
    extras_txt = f" e {', '.join(extras)}" if extras else ""
    return f"{cod} ({tipo} com {qtxt} por {price}{extras_txt})"


def _details_by_code(code: str, df: pd.DataFrame, colmap: Dict[str, str]) -> str:
    if "codigo" not in colmap: return "código do imóvel não encontrado na base"
    d = df[df[colmap["codigo"]].astype(str).str.lower() == str(code).lower()]
    if d.empty: return "imóvel não encontrado"
    r = d.iloc[0]
    parts = []
    tipo = _canon_tipo(str(r.get(colmap.get("tipo", ""), "imovel")))
    artigo_indef = "uma" if _gender(tipo) == "f" else "um"
    parts.append(f"Esse imóvel é {artigo_indef} {tipo.lower()}")
    if "quartos" in colmap:
        q = pd.to_numeric(r[colmap["quartos"]], errors="coerce")
        parts.append(f"com {int(q)} dormitórios" if pd.notna(q) else "com dormitórios n/d")
    if "banheiros" in colmap:
        b = pd.to_numeric(r[colmap["banheiros"]], errors="coerce")
        parts.append(f"{int(b)} banheiros" if pd.notna(b) else "banheiros n/d")
    if "vagas" in colmap:
        v = pd.to_numeric(r[colmap["vagas"]], errors="coerce")
        parts.append(f"{int(v)} vagas de garagem" if pd.notna(v) else "vagas n/d")
    if "valor_venda" in colmap and pd.notna(r.get(colmap["valor_venda"], np.nan)):
        parts.append(f"custa {_currency(r[colmap['valor_venda']])} para venda")
    if "valor_aluguel" in colmap and pd.notna(r.get(colmap["valor_aluguel"], np.nan)):
        parts.append(f"e {_currency(r[colmap['valor_aluguel']])} para alugar")
    if "condominio" in colmap and pd.notna(r.get(colmap["condominio"], np.nan)):
        parts.append(f"condomínio {_currency(r[colmap['condominio']])}")
    if "iptu" in colmap and pd.notna(r.get(colmap["iptu"], np.nan)):
        parts.append(f"IPTU {_currency(r[colmap['iptu']])}")
    if "mobiliado" in colmap:    parts.append("mobiliado" if _yes(r[colmap["mobiliado"]]) else "não mobiliado")
    if "aceita_pet" in colmap:   parts.append("aceita pets" if _yes(r[colmap["aceita_pet"]]) else "não aceita pets")
    if "financiamento" in colmap:parts.append("aceita financiamento" if _yes(r[colmap["financiamento"]]) else "não aceita financiamento")
    if "permuta" in colmap:      parts.append("aceita permuta" if _yes(r[colmap["permuta"]]) else "não aceita permuta")
    locs = []
    if "bairro" in colmap: locs.append(str(r[colmap["bairro"]]))
    if "cidade" in colmap: locs.append(str(r[colmap["cidade"]]))
    if locs: parts.append("localizado em " + ", ".join(locs))
    if "fiador" in colmap:
        fi = str(r.get(colmap["fiador"], "")).strip()
        parts.append(f"aceita fiador ({fi})" if fi else "informação sobre fiador não disponível")
    return ", ".join(parts) + "."


def _price_ranges_both(df: pd.DataFrame, colmap: Dict[str, str], tipo: str, bairro: str) -> Dict[str, Optional[Tuple[float, float]]]:
    d = _filter(df, colmap, tipo=tipo, bairro=bairro)
    out = {"alugar": None, "venda": None}
    if d.empty: return out
    if "valor_aluguel" in colmap:
        vals_a = pd.to_numeric(d[colmap["valor_aluguel"]], errors="coerce").dropna()
        if not vals_a.empty: out["alugar"] = (float(vals_a.min()), float(vals_a.max()))
    if "valor_venda" in colmap:
        vals_v = pd.to_numeric(d[colmap["valor_venda"]], errors="coerce").dropna()
        if not vals_v.empty: out["venda"] = (float(vals_v.min()), float(vals_v.max()))
    return out


def _price_range(df: pd.DataFrame, colmap: Dict[str, str], tipo: str, negociacao: str, bairro: str) -> Optional[Tuple[float, float]]:
    d = _filter(df, colmap, tipo=tipo, negociacao=negociacao, bairro=bairro)
    if d.empty: return None
    nrm = _norm(negociacao); cols = []
    if "venda" in nrm and "valor_venda" in colmap: cols.append(colmap["valor_venda"])
    if ("alug" in nrm or "alugar" in nrm) and "valor_aluguel" in colmap: cols.append(colmap["valor_aluguel"])
    if not cols: return None
    vals = pd.concat([pd.to_numeric(d[c], errors="coerce") for c in cols]).dropna()
    if vals.empty: return None
    return float(vals.min()), float(vals.max())


def _contagens(df: pd.DataFrame, colmap: Dict[str,str], tipo: Optional[str]=None, bairro: Optional[str]=None) -> Tuple[int,int,int,int,Dict[str,List[str]]]:
    d = _filter(df, colmap, tipo=tipo, bairro=bairro)
    if d.empty: return 0,0,0,0,{"venda":[], "alugar":[], "ambos":[]}
    cat = d[colmap["negociacao"]].apply(_neg_category); cods = d[colmap["codigo"]].astype(str)
    groups = {"venda":[], "alugar":[], "ambos":[]}
    for c, code in zip(cat, cods):
        if c in groups: groups[c].append(code)
    return len(d), len(groups["venda"]), len(groups["alugar"]), len(groups["ambos"]), groups


def _qa_fiador_por_codigo(df: pd.DataFrame, colmap: Dict[str, str]) -> List[Tuple[str,str]]:
    if "codigo" not in colmap or "fiador" not in colmap: return []
    out = []
    for _, r in df.iterrows():
        code = str(r[colmap["codigo"]]); fi = str(r.get(colmap["fiador"], "")).strip()
        q = f"O imóvel {code} aceita fiador? Qual o tipo de fiador?"
        a = (f"Sim. O imóvel {code} aceita fiador. Tipo de fiador: {fi}." if fi else
             f"Não há informação de fiador para o imóvel {code}.")
        out.append((q,a))
    return out


def _qa_quantidades_gerais(df: pd.DataFrame, colmap: Dict[str,str]) -> List[Tuple[str,str]]:
    if "codigo" not in colmap or "negociacao" not in colmap: return []
    q = "Quantos imóveis disponíveis existem no banco de dados? Separe por venda, alugar e ambos e liste os códigos."
    total, n_v, n_a, n_b, groups = _contagens(df, colmap)
    a = (f"Total de imóveis disponíveis: {total}. "
         f"Para venda: {n_v} (códigos: {', '.join(groups['venda']) or 'nenhum'}). "
         f"Para alugar: {n_a} (códigos: {', '.join(groups['alugar']) or 'nenhum'}). "
         f"Para venda e alugar (ambos): {n_b} (códigos: {', '.join(groups['ambos']) or 'nenhum'}).")
    return [(q,a)]


def _qa_quantidades_por_bairro(df: pd.DataFrame, colmap: Dict[str,str]) -> List[Tuple[str,str]]:
    if "bairro" not in colmap or "codigo" not in colmap or "negociacao" not in colmap: return []
    out = []
    bairros = sorted(df[colmap["bairro"]].dropna().astype(str).str.strip().unique().tolist())
    for b in bairros:
        q = (f"Quantos imóveis disponíveis existem no bairro {b}? "
             f"Separe por venda, alugar e ambos e liste os códigos.")
        total, n_v, n_a, n_b, groups = _contagens(df, colmap, bairro=b)
        a = (f"No bairro {b} há {total} imóveis. "
             f"Para venda: {n_v} (códigos: {', '.join(groups['venda']) or 'nenhum'}). "
             f"Para alugar: {n_a} (códigos: {', '.join(groups['alugar']) or 'nenhum'}). "
             f"Para ambos: {n_b} (códigos: {', '.join(groups['ambos']) or 'nenhum'}).")
        out.append((q,a))
    return out


def _qa_quantidades_por_tipo(df: pd.DataFrame, colmap: Dict[str,str]) -> List[Tuple[str,str]]:
    if "tipo" not in colmap or "codigo" not in colmap or "negociacao" not in colmap: return []
    out = []
    tipos = ["casa","apto","loja","terreno"]
    for t in tipos:
        t_canon = _canon_tipo(t); nome_plural = _plural_noun(t_canon); prep_plural = _prep_de(t_canon, plural=True)
        q_total = (f"Qual a quantidade total {prep_plural} {nome_plural} disponíveis no banco de dados? "
                   f"Separe por venda, alugar e ambos e liste os códigos.")
        total, n_v, n_a, n_b, groups = _contagens(df, colmap, tipo=t)
        a_total = (f"Total {prep_plural} {nome_plural}: {total}. "
                   f"Para venda: {n_v} (códigos: {', '.join(groups['venda']) or 'nenhum'}). "
                   f"Para alugar: {n_a} (códigos: {', '.join(groups['alugar']) or 'nenhum'}). "
                   f"Para ambos: {n_b} (códigos: {', '.join(groups['ambos']) or 'nenhum'}).")
        out.append((q_total, a_total))
        if "bairro" in colmap:
            bairros = sorted(df[colmap["bairro"]].dropna().astype(str).str.strip().unique().tolist())
            for b in bairros:
                q_b = (f"Qual a quantidade {prep_plural} {nome_plural} disponíveis no bairro {b}? "
                       f"Separe por venda, alugar e ambos e liste os códigos.")
                total, n_v, n_a, n_b, groups = _contagens(df, colmap, tipo=t, bairro=b)
                a_b = (f"No bairro {b}, {prep_plural} {nome_plural} somam {total}. "
                       f"Para venda: {n_v} (códigos: {', '.join(groups['venda']) or 'nenhum'}). "
                       f"Para alugar: {n_a} (códigos: {', '.join(groups['alugar']) or 'nenhum'}). "
                       f"Para ambos: {n_b} (códigos: {', '.join(groups['ambos']) or 'nenhum'}).")
                out.append((q_b, a_b))
    return out



def _fmt_code_bairro(rows: pd.DataFrame, colmap: Dict[str,str]) -> str:
    """Formata como 'im004 (bairro X), im013 (bairro Y)'. Se 'bairro' não existir, retorna só o código."""
    has_bairro = "bairro" in colmap
    cod_col = colmap.get("codigo") or next(iter(colmap.values()))
    out = []
    for _, r in rows.iterrows():
        code = str(r.get(cod_col, "")).strip()
        if not code:
            continue
        if has_bairro:
            b = str(r.get(colmap["bairro"], "")).strip()
            if b:
                out.append(f"{code} (bairro {b})")
            else:
                out.append(code)
        else:
            out.append(code)
    return ", ".join(out)


def _qa_imoveis_aceitam_pets(df: pd.DataFrame, colmap: Dict[str,str]) -> List[Tuple[str,str]]:
    """Gera a QA 'Quais imoveis aceitam pets?'."""
    if "aceita_pet" not in colmap or "codigo" not in colmap:
        return []
    mask = df[colmap["aceita_pet"]].map(_yes).fillna(False)
    d = df.loc[mask]
    q = "Quais imoveis aceitam pets?"
    if d.empty:
        a = "Nenhum dos imoveis cadastrados aceitam pets."
    else:
        a = "os imoveis " + _fmt_code_bairro(d, colmap) + " aceitam pets"
    return [(q, a)]


def _qa_tem_tipo_para_negociacao_global(df: pd.DataFrame, colmap: Dict[str,str]) -> List[Tuple[str,str]]:
    """Gera perguntas do tipo 'Tem algum(a) <tipo> pra alugar/vender?' sem restringir por bairro."""
    if "tipo" not in colmap or "codigo" not in colmap:
        return []
    out = []
    tipos = ["casa","apto","loja","terreno"]
    for t in tipos:
        tcanon = _canon_tipo(t)
        fem = (_gender(tcanon) == "f")
        # alugar
        d_alugar = _filter(df, colmap, tipo=tcanon, negociacao="alugar")
        q = f"Tem algum{'a' if fem else ''} {tcanon} pra alugar?"
        if d_alugar.empty:
            a = f"Não. No momento nao temos {tcanon}s para alugar."
        else:
            a = f"Sim. temos os imoveis " + _fmt_code_bairro(d_alugar, colmap) + " pra alugar"
        out.append((q, a))
        # vender
        d_venda = _filter(df, colmap, tipo=tcanon, negociacao="venda")
        q2 = f"Tem algum{'a' if fem else ''} {tcanon} pra vender?"
        if d_venda.empty:
            a2 = f"Não. No momento nao temos {tcanon}s para vender."
        else:
            a2 = f"Sim. temos os imoveis " + _fmt_code_bairro(d_venda, colmap) + " pra vender"
        out.append((q2, a2))
    return out


def _qa_quantos_total(df: pd.DataFrame, colmap: Dict[str,str]) -> List[Tuple[str,str]]:
    """Gera 'Quantos imoveis tem disponivel no sistema?' com breakdown por tipo."""
    if "tipo" not in colmap or "codigo" not in colmap:
        return []
    total = len(df)
    cont = {"loja":0,"terreno":0,"casa":0,"apto":0}
    for _, r in df.iterrows():
        t = _canon_tipo(str(r[colmap["tipo"]]))
        if t in cont: cont[t] += 1
    a = (f"No momento temos cadastrados {total} imoveis: "
         f"{cont.get('loja',0)} lojas, "
         f"{cont.get('terreno',0)} terrenos, "
         f"{cont.get('casa',0)} casas e "
         f"{cont.get('apto',0)} aptos")
    q = "Quantos imoveis tem disponivel no sistema?"
    return [(q, a)]


def _qa_quantos_por_tipo_global(df: pd.DataFrame, colmap: Dict[str,str]) -> List[Tuple[str,str]]:
    """Gera 'Quantos <tipo plural> tem disponivel no sistema?' com breakdown por negociação e bairros."""
    if "tipo" not in colmap or "codigo" not in colmap:
        return []
    out = []
    tipos = ["loja","terreno","casa","apto"]
    has_bairro = "bairro" in colmap
    for t in tipos:
        d_tipo = _filter(df, colmap, tipo=t)
        n_total = len(d_tipo)
        # Determina conjuntos para alugar/venda (inclui 'ambos' em ambas)
        if "negociacao" in colmap:
            cat = d_tipo[colmap["negociacao"]].astype(str).apply(_neg_category)
            d_alugar = d_tipo.loc[cat.isin(["alugar","ambos"])]
            d_venda  = d_tipo.loc[cat.isin(["venda","ambos"])]
        else:
            d_alugar = d_tipo; d_venda = d_tipo
        n_a = len(d_alugar); n_v = len(d_venda)
        bairros_a = sorted(set(d_alugar[colmap["bairro"]].dropna().astype(str))) if has_bairro and n_a>0 else []
        bairros_v = sorted(set(d_venda[colmap["bairro"]].dropna().astype(str))) if has_bairro and n_v>0 else []
        nome_plural = {"loja":"lojas","terreno":"terrenos","casa":"casas","apto":"aptos"}[t]
        q = f"Quantos {nome_plural} tem disponivel no sistema?"
        ba = f"(bairros {', '.join(bairros_a)})" if bairros_a else "(bairros n/d)"
        bv = f"(bairros {', '.join(bairros_v)})" if bairros_v else "(bairros n/d)"
        a = (f"No momento temos cadastrados {n_total} {nome_plural}: "
             f"{n_a} para alugar {ba} e {n_v} para venda {bv}")
        out.append((q, a))
    return out


def gerar_qa(
    df: pd.DataFrame,
    colmap: Dict[str, str],
    tipos: Optional[List[str]] = None,
    neg_opts: Optional[List[str]] = None,
    bairros: Optional[List[str]] = None,
    limit_codigos: Optional[int] = None,
    limit_combos: Optional[int] = None
) -> List[Tuple[str, str]]:
    qa: List[Tuple[str, str]] = []
    if tipos is None:   tipos = ['casa','apto','terreno','loja'] if "tipo" in colmap else []
    if neg_opts is None:neg_opts = ['venda','alugar','venda ou alugar']
    if bairros is None:
        bairros = []
        if "bairro" in colmap:
            bairros = sorted(df[colmap["bairro"]].dropna().astype(str).str.strip().unique().tolist())

    combos = [(t, n, b) for t in tipos for n in neg_opts for b in bairros]
    if isinstance(limit_combos, int) and limit_combos > 0: combos = combos[:limit_combos]

    for t, n, b in combos:
        t_canon = _canon_tipo(t)
        d = _filter(df, colmap, tipo=t, negociacao=n, bairro=b)
        cont = len(d)
        if cont > 1: artigo, nome = _det_algum(t_canon, True), _plural_noun(t_canon)
        else:        artigo, nome = _det_algum(t_canon, False), t_canon
        q = f"Tem {artigo} {nome} para {n} no bairro {b}?"
        a = ("Não. Infelizmente nessa região não temos imóveis desse tipo disponível."
             if d.empty else f"Sim, temos {cont} imóvel(is) nessa região. Para {n} temos " +
             ", ".join(_brief_desc(r, colmap, negociacao=n) for _, r in d.iterrows()))
        qa.append((q, a))

    codigos = _codes_list(df, colmap, limit=limit_codigos)
    for code in codigos:
        q = f"Você pode me dar mais detalhes do imóvel {code}?"
        a = _details_by_code(code, df, colmap)
        qa.append((q, a))

    for t in tipos:
        t_canon = _canon_tipo(t); prep_plural = _prep_de(t_canon, True); nome_plural = _plural_noun(t_canon)
        for n in neg_opts:
            for b in bairros:
                q = f"Qual a faixa de preços {prep_plural} {nome_plural} para {n} no bairro {b}?"
                if _norm(n) == "venda ou alugar":
                    ranges = _price_ranges_both(df, colmap, t, b); ra, rv = ranges.get("alugar"), ranges.get("venda")
                    if (ra is None) and (rv is None):
                        a = "Infelizmente nessa região não temos imóveis desse tipo disponível"
                    elif (ra is not None) and (rv is not None):
                        a = (f"Nessa região os preços {prep_plural} {nome_plural} para venda ou alugar são de "
                             f"{_currency(ra[0])} (alugar) a {_currency(rv[1])} (venda)")
                    elif (ra is not None) and (rv is None):
                        a = (f"Nessa região os preços {prep_plural} {nome_plural} para alugar são de "
                             f"{_currency(ra[0])} a {_currency(ra[1])}. "
                             f"Nao ha imoveis para venda nessa região.")
                    else:
                        a = (f"Nessa região os preços {prep_plural} {nome_plural} para venda são de "
                             f"{_currency(rv[0])} a {_currency(rv[1])}. "
                             f"Nao ha imoveis para alugar nessa região.")
                    qa.append((q, a));  continue
                pr = _price_range(df, colmap, t, n, b)
                a = ("Infelizmente nessa região não temos imóveis desse tipo disponível" if pr is None else
                     f"Nessa região os preços {prep_plural} {nome_plural} para {n} são de {_currency(pr[0])} a {_currency(pr[1])}")
                qa.append((q, a))

    qa.extend(_qa_fiador_por_codigo(df, colmap))
    qa.extend(_qa_quantidades_gerais(df, colmap))
    qa.extend(_qa_quantidades_por_bairro(df, colmap))
    qa.extend(_qa_quantidades_por_tipo(df, colmap))
    # === Novas QAs globais solicitadas ===
    qa.extend(_qa_imoveis_aceitam_pets(df, colmap))
    qa.extend(_qa_tem_tipo_para_negociacao_global(df, colmap))
    qa.extend(_qa_quantos_total(df, colmap))
    qa.extend(_qa_quantos_por_tipo_global(df, colmap))

    seen = set(); qa_unique = []
    for q, a in qa:
        if isinstance(q, str) and isinstance(a, str) and q not in seen:
            qa_unique.append((q, a)); seen.add(q)
    return qa_unique


def run_pipeline(
    input_path: Optional[str],
    out_disp_path: str,
    out_qa_path: str,
    limit_codigos: Optional[int],
    limit_combos: Optional[int]
) -> Tuple[int, int]:
    candidates = [input_path, "BD_catalogo.xlsx", str(Path.cwd() / "BD_catalogo.xlsx")]
    df_full = _load_catalog(candidates)
    if df_full.empty: raise ValueError("A planilha lida está vazia.")
    colmap_full = _build_column_map(df_full)
    if "disponivel" not in colmap_full:
        raise KeyError("Coluna 'Disponível (s/n)' não encontrada (variações aceitas). Verifique o arquivo de entrada.")
    mask_avail = df_full[colmap_full["disponivel"]].map(_yes).fillna(False)
    df_disp = df_full.loc[mask_avail].copy()
    for k in ["bairro","cidade","tipo","negociacao","codigo"]:
        if k in colmap_full: df_disp[colmap_full[k]] = df_disp[colmap_full[k]].astype(str).str.strip()
    Path(out_disp_path).parent.mkdir(parents=True, exist_ok=True)
    df_disp.to_excel(out_disp_path, index=False, engine="openpyxl")

    df_raw = pd.read_excel(out_disp_path, engine="openpyxl")
    colmap = _build_column_map(df_raw); df = df_raw.copy()

    qa_unique = gerar_qa(
        df=df, colmap=colmap,
        tipos=['casa','apto','terreno','loja'] if "tipo" in colmap else [],
        neg_opts=['venda', 'alugar', 'venda ou alugar'],
        bairros=(sorted(df[colmap["bairro"]].dropna().astype(str).str.strip().unique().tolist()) if "bairro" in colmap else []),
        limit_codigos=limit_codigos, limit_combos=limit_combos
    )
    pd.DataFrame(qa_unique, columns=["pergunta", "resposta"]).to_excel(out_qa_path, index=False, engine="openpyxl")
    return df_disp.shape[0], len(qa_unique)


# =============================================================================
# ==============================  PARTE 2 (serve)  ============================
# =============================================================================

def run_server(host: str="0.0.0.0", port: int=5000, debug: bool=False, ssl_cert: str | None = None, ssl_key: str | None = None, ssl_adhoc: bool = False) -> int:
    # Imports locais (carregados só quando servir)
    import ollama
    from flask import Flask, request, jsonify, render_template_string, make_response
    from datetime import datetime
    import threading
    import hashlib, pickle
    from collections import defaultdict
    from threading import RLock
    from typing import Set

    try:
        from zoneinfo import ZoneInfo
        FUSO = ZoneInfo("America/Sao_Paulo")
    except Exception:
        FUSO = None  # fallback sem timezone

    # ---------------- Sessões em memória ----------------
    # ---------------- Cache de embeddings (disco + memória) ----------------
    EMB_CACHE_PATH = os.path.join(os.path.dirname(__file__), "emb_cache.pkl")
    EMB_CACHE_LOCK = RLock()
    try:
        with open(EMB_CACHE_PATH, "rb") as _f:
            EMB_CACHE = pickle.load(_f)
    except Exception:
        EMB_CACHE = {}

    def _emb_from_ollama(text: str) -> np.ndarray:
        e = ollama.embeddings(model="nomic-embed-text", prompt=text)
        return np.array(e["embedding"], dtype=np.float32)

    def embed_cached(text: str) -> np.ndarray:
        h = hashlib.sha1(text.encode("utf-8")).hexdigest()
        with EMB_CACHE_LOCK:
            if h in EMB_CACHE:
                return EMB_CACHE[h]
        v = _emb_from_ollama(text)
        with EMB_CACHE_LOCK:
            EMB_CACHE[h] = v
            try:
                with open(EMB_CACHE_PATH, "wb") as _f:
                    pickle.dump(EMB_CACHE, _f)
            except Exception:
                pass
        return v

    SESS_LOCK = threading.Lock()
    SESSOES = defaultdict(lambda: {"imoveis_conversados": []})  # chaveada por cookie log_filename

    # ---------------- Captura de códigos ----------------
    CODIGOS_VALIDOS: Set[str] = set()

    def _clean_code(tok: str) -> str:
        tok = tok.strip()
        tok = re.sub(r'^[^\w-]+|[^\w-]+$', '', tok)
        return tok

    def _extrair_codigos(texto: str) -> list:
        if not texto:
            return []
        encontrados = []
        # 1) Padrão explícito 'imóvel <CODIGO>' (com/sem acento)
        for m in re.finditer(r'\bim[oó]vel(?:\s+c[oó]d(?:igo)?:?)?\s*([A-Za-z0-9_-]+)', texto, flags=re.IGNORECASE):
            c = _clean_code(m.group(1))
            if c:
                encontrados.append(c)
        # 2) Tokens que já constam na KB como códigos válidos
        for m in re.finditer(r'\b[A-Za-z0-9_-]{3,20}\b', texto):
            tok = _clean_code(m.group(0))
            if tok and tok.lower() in CODIGOS_VALIDOS and tok not in encontrados:
                encontrados.append(tok)
        # Deduplicação mantendo ordem
        seen = set(); out = []
        for c in encontrados:
            if c.lower() not in seen:
                out.append(c); seen.add(c.lower())
        return out

    def _registrar_codigos(sess_id: str, codigos: list) -> None:
        if not codigos:
            return
        with SESS_LOCK:
            lst = SESSOES[sess_id]["imoveis_conversados"]
            for c in codigos:
                if not lst or lst[-1].lower() != c.lower():
                    lst.append(c)

    def _ultimo_codigo(sess_id: str) -> str | None:
        with SESS_LOCK:
            lst = SESSOES[sess_id]["imoveis_conversados"]
            return lst[-1] if lst else None

    # ---------------- Substituição de referências ("esse imóvel", etc.) ----------------
    def _rm_acento(s: str) -> str:
        s2 = unicodedata.normalize("NFKD", s)
        s2 = "".join(ch for ch in s2 if not unicodedata.combining(ch))
        return s2.lower()

    FRASES_REF = [
        "esse imovel","este imovel","nesse imovel","neste imovel","desse imovel","deste imovel","esse ultimo imovel",
        "nesse terreno","neste terreno","esse terreno","desse terreno","deste terreno","esse ultimo terreno",
        "nesse apto","neste apto","esse apto","desse apto","deste apto","esse ultimo apto",
        "nesse apartamento","neste apartamento","esse apartamento","desse apartamento","deste apartamento","deste ultimo apartamento",
        "essa casa","esta casa","nessa casa","desta casa","dessa casa","essa ultima casa",
        "essa loja","esta loja","nessa loja","desta loja","dessa loja","dessa ultima loja",
    ]

    def _resolver_referencias(texto: str, codigo: str | None) -> str:
        if not texto or not codigo:
            return texto
        t_norm = _rm_acento(texto)
        replaced = False
        for fr in FRASES_REF:
            fr_norm = _rm_acento(fr)
            if fr_norm in t_norm:
                t_norm = t_norm.replace(fr_norm, f"imovel {codigo}")
                replaced = True
        if replaced:
            return t_norm.replace("imovel", "imóvel")
        return texto

    # Configurações
    LLM_MODEL = "llama3" # "llama3 (se maquina for rapida); mistral (se maquina for lenta)
    EMB_MODEL = "nomic-embed-text"
    FONE_ATENDENTE = "12-32929292"

    SYSTEM_PROMPT = (
        "Você é um assistente especializado em assuntos imobiliários no Brasil. "
        "Responda de forma objetiva, técnica e educada usando apenas as informações da base fornecida. "
        "Se a resposta não estiver presente com clareza na base, diga explicitamente que não encontrou "
        "e sugira contato com um atendente humano pelo telefone informado. "
        "Não faça suposições, não dê aconselhamento jurídico, financeiro ou contábil. "
        "Nunca produza conteúdo agressivo, ofensivo, discriminatório, sexualmente explícito, violento "
        "ou que viole leis. Se o usuário usar linguagem imprópria ou trouxer tema fora do escopo "
        "(não relacionado a mercado imobiliário), devolva apenas uma frase educada de correção indicando o escopo."
    )

    RESPOSTA_CORRETIVA_PADRAO = (
        "Vamos manter uma conversa respeitosa e objetiva. Posso ajudar com dúvidas sobre "
        "compra, venda e aluguel de imóveis. Se preferir atendimento humano, ligue para "
        f"{FONE_ATENDENTE}."
    )

    PADROES_OFENSIVOS = [
        r"\bporra\b", r"\bcaralho\b", r"\bfoda-se\b", r"\bmerda\b", r"\bputa\b",
        r"\bputaria\b", r"\bviad[oa]\b", r"\bbuceta\b", r"\bdesgraça\b", r"\bimbecil\b",
        r"\bidiota\b", r"\barrombado\b", r"\bburro\b", r"\bot[áa]rio\b",
        r"\bvai se fuder\b", r"\bvai tomar no cu\b", r"\bescroto\b"
    ]
    REGEX_OFENSIVOS = re.compile("|".join(PADROES_OFENSIVOS), flags=re.IGNORECASE)

    def contem_linguagem_impropria(texto: str) -> bool:
        return bool(REGEX_OFENSIVOS.search(texto or ""))

    def _norm2(txt: str) -> str:
        if not txt: return ""
        t = unicodedata.normalize("NFKD", txt)
        t = "".join(ch for ch in t if not unicodedata.combining(ch))
        return t.lower().strip()

    PALAVRAS_CHAVE_IMOB = [
        "imovel","imoveis","imobiliaria","aluguel","alugar","locacao","venda","comprar","compra",
        "corretor","corretagem","financiamento","itbi","iptu","condominio","escritura","registro",
        "vistoria","fiador","seguro fianca","caucao","contrato","chave","planta","habite se",
        "avaliacao","simulacao","comissao","exclusividade","visita","lancamento","assinar contrato",
        "dados pessoais","lgpd","seguro incendio","multa","reajuste","animais","manutencao","rescisao",
        "sinal","reserva","matricula","certidao","cartorio","banco","parcela","condomínio","habite-se",
    ]
    PALAVRAS_CHAVE_IMOB_NORM = [_norm2(w) for w in PALAVRAS_CHAVE_IMOB]
    SIM_THRESHOLD_IN_SCOPE = 0.35

    BASE_DIR = os.path.dirname(__file__)
    ARQS_KB = [
        os.path.join(BASE_DIR, "BD_perguntas_gerais.xlsx"),
        os.path.join(BASE_DIR, "temp2_perguntas.xlsx"),
    ]

    

    # --------- Carregamento do temp1_disponiveis.xlsx ---------
    DISP_PATH = os.path.join(BASE_DIR, "temp1_disponiveis.xlsx")
    DF_DISP = None
    COLMAP_DISP = None
    def _load_disp():
        nonlocal DF_DISP, COLMAP_DISP
        if not os.path.exists(DISP_PATH):
            return
        df_raw = pd.read_excel(DISP_PATH, engine="openpyxl")
        COLMAP_DISP = _build_column_map(df_raw)
        DF_DISP = df_raw.copy()
    _load_disp()

    # --------- Índice vetorial opcional dos imóveis ---------
    LISTING_DOCS = []
    LISTING_CODES = []
    LISTING_EMB = None
    if DF_DISP is not None and COLMAP_DISP is not None:
        for _, r in DF_DISP.iterrows():
            cod = str(r.get(COLMAP_DISP.get("codigo",""), "")).strip()
            tipo = str(r.get(COLMAP_DISP.get("tipo",""), "")).strip()
            neg  = str(r.get(COLMAP_DISP.get("negociacao",""), "")).strip()
            bai  = str(r.get(COLMAP_DISP.get("bairro",""), "")).strip()
            q    = r.get(COLMAP_DISP.get("quartos",""), "")
            v_v  = r.get(COLMAP_DISP.get("valor_venda",""), np.nan)
            v_a  = r.get(COLMAP_DISP.get("valor_aluguel",""), np.nan)
            doc  = f"imóvel {cod} | tipo: {tipo} | bairro: {bai} | negociacao: {neg} | quartos: {q} | venda: {_currency(v_v)} | aluguel: {_currency(v_a)}"
            LISTING_DOCS.append(doc); LISTING_CODES.append(cod)
        if LISTING_DOCS:
            LISTING_EMB = np.vstack([embed_cached(t) for t in LISTING_DOCS])

    def buscar_listings_topk(query: str, k: int = 3) -> list[str]:
        if LISTING_EMB is None or not LISTING_DOCS:
            return []
        q_vec = embed_cached(query)
        a_norm = LISTING_EMB / (np.linalg.norm(LISTING_EMB, axis=1, keepdims=True) + 1e-9)
        b_norm = q_vec / (np.linalg.norm(q_vec) + 1e-9)
        sims = a_norm @ b_norm
        idxs = np.argsort(-sims)[:k]
        return [LISTING_DOCS[i] for i in idxs]
# --- Lazy init da KB/embeddings ---
    KB: List[Dict[str,str]] = []
    KB_EMB: Optional[np.ndarray] = None

    def carregar_bases_excel(caminhos: List[str]) -> List[Dict[str, str]]:
        frames = []
        for p in caminhos:
            if not os.path.exists(p):
                raise FileNotFoundError(f"Arquivo não encontrado: {os.path.abspath(p)}")
            df = pd.read_excel(p)
            df.columns = [c.strip().lower() for c in df.columns]
            if not {"pergunta","resposta"}.issubset(df.columns):
                raise ValueError(f"Arquivo {p} deve conter colunas 'pergunta' e 'resposta'.")
            frames.append(df[["pergunta","resposta"]].dropna())
        all_df = pd.concat(frames, ignore_index=True)
        all_df = all_df.drop_duplicates(subset=["pergunta"], keep="first")
        return [{"pergunta": str(r["pergunta"]).strip(), "resposta": str(r["resposta"]).strip()}
                for _, r in all_df.iterrows()]

    def embed_textos(textos: List[str]) -> np.ndarray:
        vecs = [embed_cached(t) for t in textos]
        return np.vstack(vecs)

    def init_kb():
        nonlocal KB, KB_EMB, CODIGOS_VALIDOS
        if KB: return
        KB = carregar_bases_excel(ARQS_KB)
        if not KB: raise RuntimeError("KB vazio após leitura dos Excel.")
        KB_EMB = embed_textos([item["pergunta"] for item in KB])
        # Popular conjunto de códigos válidos a partir da KB
        try:
            for item in KB:
                for campo in ("pergunta", "resposta"):
                    for c in _extrair_codigos(item.get(campo, "")):
                        CODIGOS_VALIDOS.add(c.lower())
        except Exception:
            pass

    # Flask app
    app = Flask(__name__)
    app.secret_key = 'substitua_por_uma_chave_secreta_segura'

    # Flask 2.3+: before_first_request foi removido → inicializa KB no startup
    init_kb()

    def _now_str():
        if FUSO is not None:
            return datetime.now(FUSO).strftime("%Y-%m-%d %H:%M:%S")
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    LOG_DIR = os.path.join(BASE_DIR, "logs")
    os.makedirs(LOG_DIR, exist_ok=True)

    def _new_log_filename() -> str:
        ts = _now_str().replace("-", "").replace(":", "").replace(" ", "_")
        # Mantém padrão YYYYMMDD_HHMMSS.txt
        return ts[:8] + "_" + ts[9:15] + ".txt"

    def registrar(log_path: str, quem: str, texto: str) -> None:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{_now_str()}] {quem}: {texto}\n")

    @app.route('/')
    def index():
        log_filename = _new_log_filename()
        html = """
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>ChatBot Imobiliário</title>
          <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
          <style>
            body { margin:0; padding:0; background:#f5f5f5; font-family:'Roboto', sans-serif; }
            .chat-container { 
              width:400px; max-width:100%; height:600px; 
              background:#fff; margin:50px auto; 
              border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,0.1);
              display:flex; flex-direction:column;
            }
            .chat-header { padding:16px; background:#4CAF50; color:#fff;
              border-top-left-radius:8px; border-top-right-radius:8px;
              text-align:center; font-size:18px;
            }
            .chat-window { flex:1; padding:16px; overflow-y:auto; }
            .message { margin:8px 0; padding:12px; border-radius:20px; max-width:75%; word-wrap:break-word; }
            .user { background:#DCF8C6; margin-left:auto; text-align:right; }
            .bot  { background:#ECECEC; margin-right:auto; text-align:left; }
            .chat-input { padding:16px; border-top:1px solid #ddd; }
            .chat-input form { display:flex; }
            .chat-input input {
              flex:1; padding:10px; border:1px solid #ccc; border-radius:4px; margin-right:8px;
            }
            .chat-input button { 
              padding:10px 16px; background:#4CAF50; color:#fff; border:none; border-radius:4px;
              cursor:pointer;
            }
            .chat-input button:disabled { opacity:0.6; cursor:default; }
          </style>
        </head>
        <body>
          <div class="chat-container">
            <div class="chat-header">ChatBot Imobiliário</div>
            <div id="chat-window" class="chat-window"></div>
            <div class="chat-input">
              <form id="chat-form">
                <input type="text" id="color-input" placeholder="Digite sua pergunta (ou 'fim')" required autocomplete="off">
                <button type="submit" id="send-btn">Enviar</button>
              </form>
            </div>
          </div>

          <script>
            const form    = document.getElementById('chat-form');
            const input   = document.getElementById('color-input');
            const sendBtn = document.getElementById('send-btn');
            const chatWin = document.getElementById('chat-window');

            function addMessage(text, who) {
              const div = document.createElement('div');
              div.classList.add('message', who);
              div.textContent = text;
              chatWin.append(div);
              chatWin.scrollTop = chatWin.scrollHeight;
            }

            addMessage("Olá! Eu sou o chatbot da loja/imobiliária. Como posso ajudar?", "bot");

            form.addEventListener('submit', e => {
              e.preventDefault();
              const color = input.value.trim();
              if (!color) return;

              addMessage(color, 'user');
              input.value = '';
              input.focus();

              fetch('/translate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ color })
              })
              .then(res => res.json())
              .then(data => {
                addMessage(data.response, 'bot');
                if (data.ended) {
                  input.disabled   = true;
                  sendBtn.disabled = true;
                  addMessage('Conversa encerrada. Recarregue a página para iniciar outra.', 'bot');
                }
              });
            });
          </script>
        </body>
        </html>
        """
        resp = make_response(render_template_string(html))
        resp.set_cookie('log_filename', log_filename)

        # Inicializa sessão em memória
        with SESS_LOCK:
            _ = SESSOES[log_filename]

        log_path = os.path.join(LOG_DIR, log_filename)
        registrar(log_path, "BOT", "Olá! Eu sou o chatbot da loja/imobiliária, otimizado para fornecer respostas precisas sobre compra, venda e aluguel de imóveis.")
        return resp

    @app.route('/translate', methods=['POST'])
    def translate():
        payload      = request.get_json() or {}
        user_text    = (payload.get('color') or "").strip()
        log_filename = request.cookies.get('log_filename') or _new_log_filename()
        log_path     = os.path.join(LOG_DIR, log_filename)

        # Garante sessão
        with SESS_LOCK:
            _ = SESSOES[log_filename]

        # Resolve referências anafóricas usando o último código conversado
        _ultimo = _ultimo_codigo(log_filename)
        user_text_resolvido = _resolver_referencias(user_text, _ultimo)

        registrar(log_path, "USUÁRIO", user_text)
        if user_text_resolvido != user_text:
            registrar(log_path, "SISTEMA", f"[referência resolvida] → {user_text_resolvido}")

        if _norm2(user_text_resolvido) == "fim":
            response_text = "Chat encerrado. Até a próxima!"
            registrar(log_path, "BOT", response_text)
            return jsonify(response=response_text, ended=True)

        if contem_linguagem_impropria(user_text_resolvido):
            response_text = RESPOSTA_CORRETIVA_PADRAO
            registrar(log_path, "BOT", response_text)
            return jsonify(response=response_text, ended=False)

        try:
            def _top1_sim(query: str) -> float:
                if KB_EMB is None: return 0.0
                q_vec = np.array(ollama.embeddings(model="nomic-embed-text", prompt=query)["embedding"], dtype=np.float32)
                a_norm = KB_EMB / (np.linalg.norm(KB_EMB, axis=1, keepdims=True) + 1e-9)
                b_norm = q_vec / (np.linalg.norm(q_vec) + 1e-9)
                sims = a_norm @ b_norm
                return float(np.max(sims)) if sims.size else 0.0

            def classificar_escopo(query: str) -> bool:
                qn = _norm2(query)
                if any(k in qn for k in PALAVRAS_CHAVE_IMOB_NORM): return True
                return _top1_sim(query) >= SIM_THRESHOLD_IN_SCOPE

            if not classificar_escopo(user_text_resolvido):
                response_text = RESPOSTA_CORRETIVA_PADRAO
                registrar(log_path, "BOT", response_text)
                return jsonify(response=response_text, ended=False)
        except Exception:
            response_text = RESPOSTA_CORRETIVA_PADRAO
            registrar(log_path, "BOT", response_text)
            return jsonify(response=response_text, ended=False)

        try:
            def buscar_top_k(query: str, k: int = 5) -> List[Tuple[Dict[str, str], float]]:
                q_vec = embed_cached(query)
                a_norm = KB_EMB / (np.linalg.norm(KB_EMB, axis=1, keepdims=True) + 1e-9)
                b_norm = q_vec / (np.linalg.norm(q_vec) + 1e-9)
                sims = a_norm @ b_norm
                idxs = np.argsort(-sims)[:k]
                return [(KB[i], float(sims[i])) for i in idxs]

            candidatos = buscar_top_k(user_text_resolvido, k=5)
            contexto = [f"Q: {item['pergunta']}\nA: {item['resposta']}" for item, _ in candidatos]
            contexto_str = "\n\n".join(contexto)
            try:
                top_listings = buscar_listings_topk(user_text_resolvido, k=3)
                if top_listings:
                    contexto.append("IMÓVEIS CORRELATOS:\n" + "\n".join(f"- {t}" for t in top_listings))
            except Exception:
                pass
            contexto_str = "\n\n".join(contexto)
            user_prompt = (
                "BASE DE CONHECIMENTO (use apenas isto):\n"
                f"{contexto_str}\n\n"
                "PERGUNTA DO USUÁRIO:\n"
                f"{user_text_resolvido}\n\n"
                "INSTRUÇÕES DE RESPOSTA:\n"
                "- Responda de forma objetiva, técnica e educada.\n"
                "- Use somente a base acima; não invente informações.\n"
                "- Se a base não cobrir a pergunta com clareza, diga 'Não encontrei a resposta exata na base' "
                f"e sugira contato com atendimento humano pelo {FONE_ATENDENTE}.\n"
                "- Não forneça aconselhamento jurídico/financeiro; recomende consultar um especialista quando aplicável."
            )
            resp = ollama.chat(
                model=LLM_MODEL,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                options={"temperature": 0.2}
            )
            response_text = resp["message"]["content"].strip()
        except Exception:
            response_text = ("Ocorreu um erro ao processar sua solicitação. "
                             "Por favor, tente novamente ou contate 12-32929292.")

        # Captura e armazena códigos mencionados (na pergunta resolvida e na resposta)
        try:
            _registrar_codigos(log_filename, _extrair_codigos(user_text_resolvido))
            _registrar_codigos(log_filename, _extrair_codigos(response_text))
        except Exception:
            pass

        registrar(log_path, "BOT", response_text)
        return jsonify(response=response_text, ended=False)

    ssl_ctx = (ssl_cert, ssl_key) if (ssl_cert and ssl_key) else None
    if ssl_ctx is None and ssl_adhoc:
        ssl_ctx = 'adhoc'
    app.run(host=host, port=port, debug=debug, ssl_context=ssl_ctx)
    return 0


# =============================================================================
# ===========================  CLI e AUTO-RUN  ================================
# =============================================================================

def build_main_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="IMOBIBOT V3 — Geração de planilhas (PARTE 1) e servidor Flask (PARTE 2).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    sub = p.add_subparsers(dest="mode")
    # gen
    pg = sub.add_parser("gen", help="Gerar planilhas auxiliares a partir do BD_catalogo.xlsx")
    pg.add_argument("--input", "-i", type=str, default=None,
                    help="Caminho do arquivo de entrada (XLSX/CSV). Se omitido, tenta 'BD_catalogo.xlsx'.")
    pg.add_argument("--out-disp", type=str, default="temp1_disponiveis.xlsx",
                    help="Arquivo XLSX de saída com imóveis disponíveis.")
    pg.add_argument("--out-qa", type=str, default="temp2_perguntas.xlsx",
                    help="Arquivo XLSX de saída com perguntas e respostas.")
    pg.add_argument("--limit-codigos", type=int, default=None,
                    help="Limita a quantidade de códigos detalhados (para bases grandes).")
    pg.add_argument("--limit-combos", type=int, default=None,
                    help="Limita combinações (tipo x negociação x bairro) para as perguntas dinâmicas.")
    # serve
    ps = sub.add_parser("serve", help="Subir o servidor Flask (chatbot)")
    ps.add_argument("--host", type=str, default="0.0.0.0", help="Host do servidor Flask")
    ps.add_argument("--port", type=int, default=5000, help="Porta do servidor Flask")
    ps.add_argument("--ssl-cert", type=str, default=None, help="Caminho para certificado (PEM)")
    ps.add_argument("--ssl-key",  type=str, default=None, help="Caminho para chave privada (PEM)")
    ps.add_argument("--ssl-adhoc", action="store_true", help="Ativa TLS 'adhoc' (certificado efêmero) sem .pem")
    ps.add_argument("--debug", action="store_true", help="Ativa modo debug do Flask")
    return p


def _auto_gen_then_serve() -> int:
    """Executa PARTE 1 (gen) com defaults e, se bem-sucedido ou dados já existirem, inicia PARTE 2 (serve)."""
    input_path = "BD_catalogo.xlsx"
    out_disp   = "temp1_disponiveis.xlsx"
    out_qa     = "temp2_perguntas.xlsx"

    # 1) Tenta gerar (PARTE 1)
    try:
        n_disp, n_qa = run_pipeline(
            input_path=input_path,
            out_disp_path=out_disp,
            out_qa_path=out_qa,
            limit_codigos=None,
            limit_combos=None
        )
        print(f"[OK][PARTE 1] Gerados: {out_disp} (linhas: {n_disp}), {out_qa} (QAs: {n_qa})")
    except FileNotFoundError as e:
        print(f"[AVISO][PARTE 1] {e}")
        # Se o BD não existe, mas os temporários existem, seguimos para o servidor.
        if not (os.path.exists(out_disp) and os.path.exists(out_qa)):
            print("[ERRO] Não foi possível gerar os arquivos auxiliares e eles também não existem previamente.")
            return 2
        else:
            print("[AVISO] Usando arquivos já existentes para iniciar o servidor.")
    except KeyError as e:
        print(f"[ERRO][PARTE 1] Coluna obrigatória ausente: {e}")
        return 3
    except Exception as e:
        print(f"[ERRO][PARTE 1] Falha inesperada: {type(e).__name__}: {e}")
        return 1

    # 2) Inicia o servidor (PARTE 2)
    try:
        return run_server(host="0.0.0.0", port=5000, debug=False)
    except Exception as e:
        print(f"[ERRO][PARTE 2] Servidor: {type(e).__name__}: {e}", file=sys.stderr)
        return 1


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_main_parser()
    args = parser.parse_args(argv)

    # Sem subcomando → comportamento solicitado: rodar PARTE 1 e depois PARTE 2 automaticamente.
    if not args.mode:
        return _auto_gen_then_serve()

    if args.mode == "gen":
        try:
            n_disp, n_qa = run_pipeline(
                input_path=args.input,
                out_disp_path=args.out_disp,
                out_qa_path=args.out_qa,
                limit_codigos=args.limit_codigos,
                limit_combos=args.limit_combos
            )
            print(f"[OK] Arquivo de imóveis disponíveis: {args.out_disp} (linhas: {n_disp})")
            print(f"[OK] Arquivo de Perguntas/Respostas: {args.out_qa} (total de linhas: {n_qa})")
            return 0
        except FileNotFoundError as e:
            print(f"[ERRO] {e}", file=sys.stderr); return 2
        except KeyError as e:
            print(f"[ERRO] Coluna obrigatória ausente: {e}", file=sys.stderr); return 3
        except Exception as e:
            print(f"[ERRO] Falha inesperada: {type(e).__name__}: {e}", file=sys.stderr); return 1

    if args.mode == "serve":
        try:
            return run_server(host=args.host, port=args.port, debug=args.debug, ssl_cert=getattr(args, 'ssl_cert', None), ssl_key=getattr(args, 'ssl_key', None), ssl_adhoc=getattr(args, 'ssl_adhoc', False))
        except Exception as e:
            print(f"[ERRO] Servidor: {type(e).__name__}: {e}", file=sys.stderr); return 1

    print("Modo inválido.", file=sys.stderr); return 1


if __name__ == "__main__":
    sys.exit(main())
