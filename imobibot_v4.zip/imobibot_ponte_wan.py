import os
import time
import threading
from pyngrok import ngrok, conf

# =====================================================
# ⚠️  COLE SEU TOKEN DO NGROK AQUI DENTRO DAS ASPAS
SEU_TOKEN = "35njQlDD70FErCwIHVo2iRQnmBo_5tpoxSCoWq4SfnuwYvick"
# =====================================================

PORTA = 5000

def iniciar_streamlit():
    # Esta função roda o site em segundo plano
    print("   -> Iniciando Streamlit...")
    # O comando >nul esconde o texto do streamlit para não poluir a tela
    os.system(f"streamlit run imobibot_v4.py --server.port {PORTA} --server.headless true")

def main():
    # 1. Mata processos antigos do ngrok para evitar erros
    os.system("taskkill /f /im ngrok.exe >nul 2>&1")
    
    # 2. Configura o token
    print("1. Configurando autenticação...")
    ngrok.set_auth_token(SEU_TOKEN)

    # 3. Inicia o Site numa linha paralela (Thread)
    print("2. Ligando o Imobibot...")
    thread_site = threading.Thread(target=iniciar_streamlit)
    thread_site.daemon = True
    thread_site.start()

    # Espera 5 segundos para o site subir
    time.sleep(5)

    # 4. Abre o Túnel
    print("3. Abrindo túnel para a internet...")
    try:
        url_publica = ngrok.connect(PORTA).public_url
    except Exception as e:
        print(f"❌ Erro ao conectar: {e}")
        return

    # 5. MOSTRA O LINK FINAL
    print("\n" + "="*50)
    print(f"✅ TUDO PRONTO! O ROBÔ ESTÁ ONLINE.")
    print(f"⚠️  ATENÇÃO: O link mudou! Use o novo abaixo:")
    print(f"\n👉  {url_publica}  👈\n")
    print("="*50)
    print("🛑 NÃO FECHE ESTA JANELA ENQUANTO QUISER USAR O ROBÔ.")

    # Mantém o script rodando eternamente
    while True:
        time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nDesligando tudo...")